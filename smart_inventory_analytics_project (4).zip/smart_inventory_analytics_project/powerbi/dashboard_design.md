# Power BI Dashboard Design Specification

## Smart Inventory & Food Waste Analytics Platform — 6-Page Report

---

## Page 1 — Executive Summary

**Slicers:** Date Range, Region, Category, Store Tier

**KPI Cards (top row):**
- Revenue (with YoY sparkline)
- Gross Profit (conditional color: green if positive)
- Waste % (gauge visual vs 5% target line)
- Stockout Rate (gauge visual vs 10% target line)

**Main Visuals:**
- Revenue/Profit/Waste combo trend chart (monthly, dual-axis line + bar), tooltip shows YoY% change
- Category revenue mix donut chart with drill-down to brand level

---

## Page 2 — Inventory Health Score

**Visuals:**
- Composite Health Score gauge (0–100, weighted formula below)
- Health Score ranked bar chart by store, color-banded (red <50, amber 50–75, green >75)
- High-Risk Inventory matrix table (from SQL risk-score query), conditional formatting on Risk_Score column

**DAX — Health Score:**
```dax
Health Score = 
    (100 - [Stockout Rate %]) * 0.35 +
    [Avg Forecast Accuracy %] * 0.35 +
    (100 - [Near Expiry Rate %]) * 0.30
```

---

## Page 3 — Waste Heatmap & Root Cause

**Visuals:**
- Matrix heatmap: Category (rows) × Season (columns), color saturation = waste value, drill-through enabled to Product Detail page
- Waste reason donut (Expiry / Damage / Quality Reject / Over-Stock / Cold-Chain Break)
- Temperature vs Waste scatter plot with trendline, play-axis animation by month
- **Drill-through target page:** Product Waste Detail — right-click any heatmap cell to see SKU-level waste log

---

## Page 4 — Demand Forecast

**Visuals:**
- Revenue forecast using Power BI's built-in Analytics pane forecasting feature, 12-month horizon, 95% CI band
- Forecast accuracy by category bar chart, red flag below 75% threshold
- **What-If Parameter:** Safety Stock Multiplier (0.8x – 2.0x slider)

**DAX — What-If simulation:**
```dax
Simulated Stockout % = 
VAR Multiplier = 'Safety Stock Param'[Safety Stock Param Value]
RETURN 
    CALCULATE(
        DIVIDE(
            COUNTROWS(FILTER(inventory, inventory[Stock_Level] * Multiplier < inventory[Min_Stock_Level])),
            COUNTROWS(inventory)
        )
    ) * 100
```

---

## Page 5 — Store & Supplier Comparison

**Visuals:**
- Bubble map by city (size = Revenue, color = Margin %)
- Store scorecard matrix: Revenue, Margin, Waste%, Stockout% with conditional icons
- Supplier scorecard table: Reliability, On-Time%, Defect%, Linked Waste, Grade (A–D)

---

## Page 6 — Customer & Promotion Analysis

**Visuals:**
- Customer segment treemap (size = Revenue, color = Avg Discount Used)
- Promotion effectiveness clustered bar (Promo vs No-Promo: Revenue/Txn, Margin%)
- **Bookmarks:** "View: Profit Focus" / "View: Waste Focus" — toggle KPI card emphasis without changing active filters

---

## Core DAX Measure Library

```dax
-- Total Revenue
Total Revenue = SUM(sales[Revenue])

-- Total Gross Profit
Total Profit = SUM(sales[Gross_Profit])

-- Gross Margin %
Margin Pct = DIVIDE([Total Profit], [Total Revenue]) * 100

-- Waste % of Revenue
Waste Pct = DIVIDE([Total Waste Value], [Total Revenue] + [Total Waste Value]) * 100

-- Stockout Rate %
Stockout Rate % = 
    DIVIDE(
        CALCULATE(COUNTROWS(inventory), inventory[Is_Stockout] = TRUE),
        COUNTROWS(inventory)
    ) * 100

-- YoY Revenue Growth
YoY Revenue % = 
VAR CY = [Total Revenue]
VAR PY = CALCULATE([Total Revenue], SAMEPERIODLASTYEAR('Date'[Date]))
RETURN DIVIDE(CY - PY, PY) * 100

-- Preventable Waste Value
Preventable Waste = CALCULATE(SUM(waste[Waste_Value_INR]), waste[Preventable] = TRUE)

-- Customer Lifetime Value (proxy)
CLV = DIVIDE([Total Revenue], DISTINCTCOUNT(sales[Customer_ID]))

-- Inventory Turnover Ratio
Turnover Ratio = DIVIDE(SUM(sales[COGS]), AVERAGE(inventory[Stock_Level]) * AVERAGE(products[Purchase_Cost]))
```

---

## Bookmark & Tooltip Notes

- **Tooltip pages:** Hovering any product bar shows a mini tooltip page with Product_Name, Category, Days_To_Expiry, and Risk_Score
- **Bookmarks:** Used on Page 6 to switch between Profit-Focus and Waste-Focus KPI emphasis; implemented via "Selection" + "Data" bookmark options without altering active slicer state
- **Drill-through:** Configured from the Waste Heatmap (Page 3) and Store Scorecard (Page 5) down to SKU/Store-level detail pages, passing Category and Store_ID as drill-through filters
