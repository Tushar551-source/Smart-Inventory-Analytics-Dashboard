# 🛒 Smart Inventory & Food Waste Analytics Platform

End-to-end data analytics project simulating a supermarket chain's inventory and waste management system — built to demonstrate the full analyst workflow from synthetic data generation through SQL analysis, Python EDA/forecasting, and Power BI dashboard design.

## 📌 Problem Statement

A 15-store supermarket chain faces rising food waste and frequent stockouts on perishables. This project builds the analytics layer to diagnose root causes and recommend fixes — quantifying ₹38M in annual waste (4.8% of revenue), of which 55% is preventable.

## 🗂️ Repository Structure

```
inventory-waste-analytics/
├── data/
│   ├── generate_data.py        # Synthetic dataset generator (10 tables, 130K+ rows)
│   ├── products.csv
│   ├── suppliers.csv
│   ├── stores.csv
│   ├── customers.csv
│   ├── inventory.csv
│   ├── sales.csv
│   ├── waste.csv
│   ├── promotions.csv
│   ├── weather.csv
│   └── holidays.csv
├── sql/
│   └── advanced_queries.sql    # 15 queries: schema, KPIs, risk scoring, window functions
├── python/
│   └── analysis.py             # Cleaning, EDA, KPIs, Holt-Winters forecast, 12 charts
├── powerbi/
│   └── dashboard_design.md     # 6-page dashboard spec with DAX measures
└── README.md
```

## 🛠️ Tech Stack

`Python` · `Pandas` · `NumPy` · `Matplotlib` · `Statsmodels` · `SQL` · `Power BI` · `DAX`

## 📊 Key Results

- Analyzed 130,628 records across 10 interlinked tables (Products, Suppliers, Inventory, Stores, Sales, Waste, Promotions, Weather, Holidays, Customers)
- Identified that Expiry-related waste (40% of total) is the single largest preventable loss driver
- Built a composite Inventory Health Score combining stockout rate, forecast accuracy, and near-expiry rate
- Forecasted 12-month revenue using Holt-Winters Exponential Smoothing with seasonal decomposition
- Designed a 6-page Power BI dashboard with drill-through, bookmarks, and What-If safety-stock simulation

## 📈 KPIs Tracked

| KPI | Value |
|---|---|
| Total Revenue | ₹753.1M |
| Gross Profit | ₹98.9M |
| Gross Margin | 13.1% |
| Total Waste Value | ₹38.0M |
| Waste % of Revenue | 4.8% |
| Stockout Rate | 14.9% |
| Avg Forecast Accuracy | 86.5% |
| Inventory Turnover | 9.9x |

## 🚀 How to Run

```bash
pip install -r requirements.txt
python data/generate_data.py      # generates all 10 CSVs (~2 min)
python python/analysis.py         # runs cleaning, EDA, forecasting, charts
# Then open powerbi/dashboard.pbix or follow dashboard_design.md to rebuild
```

## 📈 Sample Insight

> "Waste value rises sharply above 34°C across all perishable categories — confirming the need for temperature-triggered dynamic reordering rather than static safety-stock rules."

## 💡 Top Business Recommendations

1. **Implement FEFO enforcement** — Expiry drives 40% of waste value; barcode-scan-enforced first-expiry-first-out picking targets this directly.
2. **Temperature-triggered dynamic reordering** — Auto-reduce order quantities for perishables when forecast temperature exceeds 34°C.
3. **Fix supplier lead-time mismatches** — Suppliers below 90% on-time delivery show measurably higher linked waste.
4. **Use promotions as a waste-clearance tool** — Auto-trigger markdowns on near-expiry stock rather than waiting for manual promo decisions.

## 👤 Author

Built as a portfolio project demonstrating end-to-end retail analytics: data engineering, SQL, Python, statistical forecasting, and BI dashboard design.

## 📄 License

MIT License — feel free to fork and extend.
