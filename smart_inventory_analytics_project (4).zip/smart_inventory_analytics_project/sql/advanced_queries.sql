-- ══════════════════════════════════════════════════════════════════════════════
-- SMART INVENTORY & FOOD WASTE ANALYTICS PLATFORM
-- Advanced SQL Queries  ·  PostgreSQL / MySQL / SQL Server compatible
-- ══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- 0. SCHEMA — TABLE CREATION
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE products (
    Product_ID         VARCHAR(10) PRIMARY KEY,
    Product_Name       VARCHAR(150),
    Category           VARCHAR(50),
    Brand               VARCHAR(50),
    Supplier_ID         VARCHAR(20),
    Purchase_Cost       DECIMAL(10,2),
    Selling_Price       DECIMAL(10,2),
    Profit_Per_Unit     DECIMAL(10,2),
    Margin_Pct          DECIMAL(5,2),
    Shelf_Life_Days     INT,
    Manufacturing_Date  DATE,
    Expiry_Date         DATE,
    Min_Stock_Level     INT,
    Reorder_Point       INT,
    Unit                VARCHAR(20),
    Storage_Temp_C      INT
);

CREATE TABLE suppliers (
    Supplier_ID          VARCHAR(20) PRIMARY KEY,
    Supplier_Name         VARCHAR(100),
    Category               VARCHAR(50),
    Region                 VARCHAR(20),
    Lead_Time_Days         INT,
    Reliability_Score      DECIMAL(4,2),
    Min_Order_Qty          INT,
    Payment_Terms_Days     INT,
    Contract_Start         DATE,
    Rating                 DECIMAL(3,1),
    On_Time_Delivery_Pct   DECIMAL(5,1),
    Defect_Rate_Pct        DECIMAL(5,2)
);

CREATE TABLE stores (
    Store_ID            VARCHAR(20) PRIMARY KEY,
    Store_Name           VARCHAR(100),
    Region               VARCHAR(20),
    Tier                 VARCHAR(20),
    City                 VARCHAR(50),
    Area_SqFt            INT,
    Opening_Year         INT,
    Manager              VARCHAR(50),
    Staff_Count          INT,
    Cold_Storage_Pct     DECIMAL(4,2),
    Avg_Daily_Footfall   INT,
    Has_Online_Order     BOOLEAN
);

CREATE TABLE customers (
    Customer_ID       VARCHAR(20) PRIMARY KEY,
    Customer_Type      VARCHAR(20),
    Region              VARCHAR(20),
    Age_Group            VARCHAR(10),
    Loyalty_Score        INT,
    Avg_Basket_Size      DECIMAL(10,2),
    Visit_Frequency      VARCHAR(20),
    Online_Shopper       BOOLEAN,
    Member_Since         DATE
);

CREATE TABLE inventory (
    Inv_ID              VARCHAR(20) PRIMARY KEY,
    Date                 DATE,
    Store_ID              VARCHAR(20),
    Region                VARCHAR(20),
    Product_ID            VARCHAR(10),
    Category               VARCHAR(50),
    Stock_Received          INT,
    Stock_Level             INT,
    Min_Stock_Level         INT,
    Is_Stockout             BOOLEAN,
    Days_To_Expiry          INT,
    Near_Expiry_Flag        BOOLEAN,
    Reorder_Triggered       BOOLEAN,
    Temperature_C           DECIMAL(4,1),
    Rainfall_mm              DECIMAL(5,1),
    Season                   VARCHAR(20),
    Demand_Forecast          INT,
    Actual_Demand             INT,
    Forecast_Error            INT,
    Forecast_Acc_Pct          DECIMAL(5,1)
);

CREATE TABLE sales (
    Sale_ID             VARCHAR(20) PRIMARY KEY,
    Date                 DATE,
    Store_ID              VARCHAR(20),
    Region                VARCHAR(20),
    Product_ID            VARCHAR(10),
    Category               VARCHAR(50),
    Customer_ID            VARCHAR(20),
    Customer_Type          VARCHAR(20),
    Quantity_Sold           INT,
    Purchase_Cost            DECIMAL(10,2),
    Selling_Price            DECIMAL(10,2),
    Effective_Price          DECIMAL(10,2),
    Discount_Pct              DECIMAL(5,2),
    Promo_Active               BOOLEAN,
    Revenue                    DECIMAL(12,2),
    COGS                        DECIMAL(12,2),
    Gross_Profit                 DECIMAL(12,2),
    Gross_Margin_Pct              DECIMAL(5,2),
    Is_Weekend                    BOOLEAN,
    Festival                      VARCHAR(50)
);

CREATE TABLE waste (
    Waste_ID            VARCHAR(20) PRIMARY KEY,
    Date                 DATE,
    Store_ID              VARCHAR(20),
    Region                VARCHAR(20),
    Product_ID            VARCHAR(10),
    Category               VARCHAR(50),
    Waste_Quantity          INT,
    Waste_Value_INR          DECIMAL(12,2),
    Waste_Reason              VARCHAR(30),
    Temperature_C              DECIMAL(4,1),
    Days_To_Expiry              INT,
    Near_Expiry                 BOOLEAN,
    Season                      VARCHAR(20),
    Preventable                 BOOLEAN
);

CREATE TABLE promotions (
    Promo_ID          VARCHAR(20) PRIMARY KEY,
    Promo_Name         VARCHAR(100),
    Category             VARCHAR(50),
    Store_ID              VARCHAR(20),
    Promo_Type            VARCHAR(30),
    Discount_Pct           DECIMAL(5,2),
    Start_Date              DATE,
    End_Date                DATE,
    Min_Purchase             DECIMAL(10,2),
    Budget_INR                DECIMAL(12,2),
    Target_Revenue             DECIMAL(12,2)
);

CREATE TABLE weather (
    Date              DATE,
    Region              VARCHAR(20),
    Temperature_C        DECIMAL(4,1),
    Rainfall_mm           DECIMAL(5,1),
    Humidity_Pct           DECIMAL(4,1),
    Weather_Condition       VARCHAR(20)
);

CREATE TABLE holidays (
    Date               DATE PRIMARY KEY,
    Day_Of_Week          VARCHAR(15),
    Is_Weekend             BOOLEAN,
    Is_Holiday              BOOLEAN,
    Festival_Name            VARCHAR(50),
    Demand_Multiplier         DECIMAL(4,2),
    Season                    VARCHAR(20)
);


-- ═══════════════════════════════════════════════════════════════════════════════
-- 1. EXECUTIVE KPI SUMMARY
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    ROUND(SUM(Revenue), 2)                                  AS Total_Revenue,
    ROUND(SUM(Gross_Profit), 2)                             AS Total_Gross_Profit,
    ROUND(SUM(Gross_Profit) / SUM(Revenue) * 100, 2)       AS Gross_Margin_Pct,
    COUNT(DISTINCT Sale_ID)                                 AS Total_Transactions,
    COUNT(DISTINCT Customer_ID)                             AS Unique_Customers,
    ROUND(SUM(Revenue) / COUNT(DISTINCT Sale_ID), 2)       AS Avg_Transaction_Value
FROM sales;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 2. WASTE % AND PREVENTABLE WASTE BREAKDOWN
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    ROUND(SUM(w.Waste_Value_INR), 2)                                       AS Total_Waste_Value,
    ROUND(SUM(CASE WHEN w.Preventable=1 THEN w.Waste_Value_INR ELSE 0 END),2) AS Preventable_Waste,
    ROUND(SUM(CASE WHEN w.Preventable=1 THEN w.Waste_Value_INR ELSE 0 END)
          / SUM(w.Waste_Value_INR) * 100, 2)                              AS Preventable_Pct,
    ROUND(SUM(w.Waste_Value_INR) / (SELECT SUM(Revenue) FROM sales) * 100, 2) AS Waste_Pct_Of_Revenue
FROM waste w;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 3. STOCKOUT RATE BY CATEGORY & STORE
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Category,
    Store_ID,
    COUNT(*)                                                AS Total_Observations,
    SUM(CASE WHEN Is_Stockout=1 THEN 1 ELSE 0 END)         AS Stockout_Events,
    ROUND(AVG(CASE WHEN Is_Stockout=1 THEN 1.0 ELSE 0 END)*100, 2) AS Stockout_Rate_Pct,
    ROUND(AVG(Forecast_Acc_Pct), 2)                        AS Avg_Forecast_Accuracy
FROM inventory
GROUP BY Category, Store_ID
HAVING AVG(CASE WHEN Is_Stockout=1 THEN 1.0 ELSE 0 END) > 0.10   -- high-risk only
ORDER BY Stockout_Rate_Pct DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 4. HIGH-RISK INVENTORY  (CTE: near-expiry + high-value + low forecast accuracy)
-- ═══════════════════════════════════════════════════════════════════════════════
WITH risk_scores AS (
    SELECT
        i.Product_ID,
        p.Product_Name,
        i.Category,
        i.Store_ID,
        i.Stock_Level,
        i.Days_To_Expiry,
        p.Purchase_Cost,
        (i.Stock_Level * p.Purchase_Cost)                          AS Inventory_Value,
        i.Forecast_Acc_Pct,
        CASE
            WHEN i.Days_To_Expiry <= 2 THEN 40
            WHEN i.Days_To_Expiry <= 5 THEN 25
            ELSE 0
        END +
        CASE
            WHEN (i.Stock_Level * p.Purchase_Cost) > 50000 THEN 30
            WHEN (i.Stock_Level * p.Purchase_Cost) > 20000 THEN 15
            ELSE 0
        END +
        CASE
            WHEN i.Forecast_Acc_Pct < 70 THEN 30
            WHEN i.Forecast_Acc_Pct < 85 THEN 15
            ELSE 0
        END                                                          AS Risk_Score
    FROM inventory i
    JOIN products p ON i.Product_ID = p.Product_ID
)
SELECT *,
    CASE
        WHEN Risk_Score >= 70 THEN 'CRITICAL'
        WHEN Risk_Score >= 40 THEN 'HIGH'
        WHEN Risk_Score >= 20 THEN 'MEDIUM'
        ELSE 'LOW'
    END AS Risk_Category
FROM risk_scores
WHERE Risk_Score >= 40
ORDER BY Risk_Score DESC, Inventory_Value DESC
LIMIT 100;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 5. INVENTORY TURNOVER BY CATEGORY  (COGS / Avg Inventory Value)
-- ═══════════════════════════════════════════════════════════════════════════════
WITH cogs_cte AS (
    SELECT Category, SUM(COGS) AS Total_COGS
    FROM sales GROUP BY Category
),
inv_value_cte AS (
    SELECT i.Category,
           AVG(i.Stock_Level * p.Purchase_Cost) AS Avg_Inventory_Value
    FROM inventory i
    JOIN products p ON i.Product_ID = p.Product_ID
    GROUP BY i.Category
)
SELECT
    c.Category,
    ROUND(c.Total_COGS, 2)             AS Total_COGS,
    ROUND(v.Avg_Inventory_Value, 2)    AS Avg_Inventory_Value,
    ROUND(c.Total_COGS / NULLIF(v.Avg_Inventory_Value,0), 2) AS Turnover_Ratio
FROM cogs_cte c
JOIN inv_value_cte v ON c.Category = v.Category
ORDER BY Turnover_Ratio DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 6. WASTE HEATMAP DATA  (Category × Season pivot source)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Category,
    Season,
    COUNT(*)                            AS Waste_Events,
    ROUND(SUM(Waste_Quantity), 0)       AS Total_Qty_Wasted,
    ROUND(SUM(Waste_Value_INR), 2)      AS Total_Waste_Value
FROM waste
GROUP BY Category, Season
ORDER BY Category, Total_Waste_Value DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 7. DEMAND FORECAST ACCURACY  BY STORE (ranked, with window function)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Store_ID,
    Category,
    ROUND(AVG(Forecast_Acc_Pct), 2)                            AS Avg_Forecast_Accuracy,
    RANK() OVER (PARTITION BY Category ORDER BY AVG(Forecast_Acc_Pct) DESC) AS Accuracy_Rank
FROM inventory
GROUP BY Store_ID, Category
ORDER BY Category, Accuracy_Rank;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 8. STORE COMPARISON  (Revenue, Margin, Waste %, Stockout Rate in one view)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    s.Store_ID,
    st.Region,
    st.Tier,
    ROUND(SUM(s.Revenue), 2)                                      AS Revenue,
    ROUND(SUM(s.Gross_Profit), 2)                                 AS Gross_Profit,
    ROUND(SUM(s.Gross_Profit)/SUM(s.Revenue)*100, 2)             AS Margin_Pct,
    ROUND(COALESCE(w.Waste_Value,0)/SUM(s.Revenue)*100, 2)      AS Waste_Pct_Of_Revenue,
    ROUND(COALESCE(i.Stockout_Rate,0), 2)                        AS Stockout_Rate_Pct
FROM sales s
JOIN stores st ON s.Store_ID = st.Store_ID
LEFT JOIN (
    SELECT Store_ID, SUM(Waste_Value_INR) AS Waste_Value
    FROM waste GROUP BY Store_ID
) w ON s.Store_ID = w.Store_ID
LEFT JOIN (
    SELECT Store_ID, AVG(CASE WHEN Is_Stockout=1 THEN 1.0 ELSE 0 END)*100 AS Stockout_Rate
    FROM inventory GROUP BY Store_ID
) i ON s.Store_ID = i.Store_ID
GROUP BY s.Store_ID, st.Region, st.Tier, w.Waste_Value, i.Stockout_Rate
ORDER BY Revenue DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 9. SUPPLIER PERFORMANCE SCORECARD
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    sup.Supplier_ID,
    sup.Supplier_Name,
    sup.Category,
    sup.On_Time_Delivery_Pct,
    sup.Defect_Rate_Pct,
    sup.Reliability_Score,
    COALESCE(ROUND(SUM(w.Waste_Value_INR), 2), 0)               AS Linked_Waste_Value,
    CASE
        WHEN sup.Reliability_Score >= 0.95 AND sup.Defect_Rate_Pct < 1 THEN 'A - Excellent'
        WHEN sup.Reliability_Score >= 0.85 AND sup.Defect_Rate_Pct < 2 THEN 'B - Good'
        WHEN sup.Reliability_Score >= 0.75                          THEN 'C - Average'
        ELSE 'D - Needs Review'
    END                                                            AS Performance_Grade
FROM suppliers sup
LEFT JOIN products p   ON sup.Supplier_ID = p.Supplier_ID
LEFT JOIN waste w        ON p.Product_ID = w.Product_ID
GROUP BY sup.Supplier_ID, sup.Supplier_Name, sup.Category,
         sup.On_Time_Delivery_Pct, sup.Defect_Rate_Pct, sup.Reliability_Score
ORDER BY sup.Reliability_Score DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 10. PROMOTION EFFECTIVENESS  (lift in revenue & margin impact)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Promo_Active,
    COUNT(*)                                       AS Transactions,
    ROUND(AVG(Revenue), 2)                        AS Avg_Revenue_Per_Txn,
    ROUND(AVG(Gross_Margin_Pct), 2)               AS Avg_Margin_Pct,
    ROUND(AVG(Quantity_Sold), 2)                  AS Avg_Qty_Sold,
    ROUND(SUM(Revenue), 2)                        AS Total_Revenue
FROM sales
GROUP BY Promo_Active;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 11. WEATHER CORRELATION WITH WASTE  (temperature bands)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    CASE
        WHEN w.Temperature_C < 20 THEN 'Cold (<20°C)'
        WHEN w.Temperature_C < 28 THEN 'Normal (20-28°C)'
        WHEN w.Temperature_C < 34 THEN 'Warm (28-34°C)'
        ELSE 'Hot (>34°C)'
    END                                          AS Temp_Band,
    COUNT(*)                                     AS Waste_Events,
    ROUND(AVG(w.Waste_Value_INR), 2)            AS Avg_Waste_Value,
    ROUND(SUM(w.Waste_Value_INR), 2)            AS Total_Waste_Value
FROM waste w
GROUP BY Temp_Band
ORDER BY Avg_Waste_Value DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 12. MONTHLY TREND  (for Power BI time series + Power BI native forecast)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    DATE_FORMAT(Date, '%Y-%m')                          AS YearMonth,
    ROUND(SUM(Revenue), 2)                              AS Revenue,
    ROUND(SUM(Gross_Profit), 2)                         AS Gross_Profit,
    ROUND(SUM(Gross_Profit)/SUM(Revenue)*100, 2)       AS Margin_Pct,
    COUNT(DISTINCT Sale_ID)                             AS Transactions
FROM sales
GROUP BY YearMonth
ORDER BY YearMonth;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 13. CUSTOMER SEGMENT VALUE ANALYSIS
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Customer_Type,
    COUNT(DISTINCT Customer_ID)                          AS Customers,
    COUNT(*)                                              AS Transactions,
    ROUND(SUM(Revenue), 2)                                AS Total_Revenue,
    ROUND(SUM(Revenue)/COUNT(DISTINCT Customer_ID), 2)   AS Revenue_Per_Customer,
    ROUND(AVG(Discount_Pct), 2)                          AS Avg_Discount_Used,
    ROUND(SUM(CASE WHEN Promo_Active=1 THEN 1 ELSE 0 END)
          /COUNT(*)*100, 2)                              AS Promo_Usage_Pct
FROM sales
GROUP BY Customer_Type
ORDER BY Total_Revenue DESC;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 14. RUNNING TOTAL / CUMULATIVE WASTE (window function)
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    Date,
    Category,
    SUM(Waste_Value_INR)                                                  AS Daily_Waste,
    SUM(SUM(Waste_Value_INR)) OVER (
        PARTITION BY Category ORDER BY Date
    )                                                                      AS Cumulative_Waste
FROM waste
GROUP BY Date, Category
ORDER BY Category, Date;


-- ═══════════════════════════════════════════════════════════════════════════════
-- 15. TOP 10 LOSS-MAKING PRODUCT-STORE COMBINATIONS
-- ═══════════════════════════════════════════════════════════════════════════════
SELECT
    s.Product_ID,
    p.Product_Name,
    s.Store_ID,
    ROUND(SUM(s.Gross_Profit), 2)                AS Total_Profit,
    ROUND(COALESCE(SUM(w.Waste_Value_INR),0), 2) AS Total_Waste_Value,
    ROUND(SUM(s.Gross_Profit) - COALESCE(SUM(w.Waste_Value_INR),0), 2) AS Net_Contribution
FROM sales s
JOIN products p ON s.Product_ID = p.Product_ID
LEFT JOIN waste w ON s.Product_ID = w.Product_ID AND s.Store_ID = w.Store_ID
GROUP BY s.Product_ID, p.Product_Name, s.Store_ID
ORDER BY Net_Contribution ASC
LIMIT 10;
