"""
Smart Inventory & Food Waste Analytics Platform
Dataset Generator — ~120,000 records across 10 tables
Real-world business logic: Amazon Fresh / Walmart / DMart patterns
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random, warnings, os
warnings.filterwarnings('ignore')
np.random.seed(2024); random.seed(2024)

OUT = '/home/claude/inventory_analytics/data'
os.makedirs(OUT, exist_ok=True)

# ── MASTER CONFIG ──────────────────────────────────────────────────────────────
START = datetime(2022, 1, 1)
END   = datetime(2024, 12, 31)
DAYS  = (END - START).days + 1

CATEGORIES = {
    'Dairy':        {'shelf_days':(3,14),   'base_cost':(15,120), 'margin':(0.10,0.22), 'waste_rate':(0.04,0.14)},
    'Bakery':       {'shelf_days':(1,7),    'base_cost':(10,80),  'margin':(0.18,0.32), 'waste_rate':(0.06,0.18)},
    'Fruits':       {'shelf_days':(3,14),   'base_cost':(20,200), 'margin':(0.20,0.40), 'waste_rate':(0.08,0.22)},
    'Vegetables':   {'shelf_days':(2,10),   'base_cost':(8,150),  'margin':(0.22,0.42), 'waste_rate':(0.08,0.24)},
    'Meat':         {'shelf_days':(2,7),    'base_cost':(80,500), 'margin':(0.12,0.24), 'waste_rate':(0.03,0.10)},
    'Seafood':      {'shelf_days':(1,5),    'base_cost':(100,600),'margin':(0.14,0.28), 'waste_rate':(0.04,0.12)},
    'Frozen':       {'shelf_days':(30,180), 'base_cost':(30,300), 'margin':(0.14,0.26), 'waste_rate':(0.01,0.05)},
    'Beverages':    {'shelf_days':(30,365), 'base_cost':(15,200), 'margin':(0.16,0.32), 'waste_rate':(0.01,0.04)},
    'Snacks':       {'shelf_days':(30,180), 'base_cost':(10,150), 'margin':(0.20,0.38), 'waste_rate':(0.01,0.04)},
    'Condiments':   {'shelf_days':(60,365), 'base_cost':(20,180), 'margin':(0.18,0.34), 'waste_rate':(0.01,0.03)},
    'Grains':       {'shelf_days':(60,730), 'base_cost':(25,200), 'margin':(0.12,0.22), 'waste_rate':(0.005,0.02)},
    'Organic':      {'shelf_days':(3,14),   'base_cost':(40,350), 'margin':(0.24,0.44), 'waste_rate':(0.06,0.20)},
}

REGIONS  = ['North','South','East','West','Central']
STORES   = {
    'North':   ['Store_N01','Store_N02','Store_N03'],
    'South':   ['Store_S01','Store_S02','Store_S03','Store_S04'],
    'East':    ['Store_E01','Store_E02','Store_E03'],
    'West':    ['Store_W01','Store_W02','Store_W03'],
    'Central': ['Store_C01','Store_C02'],
}
ALL_STORES = [s for lst in STORES.values() for s in lst]

STORE_TIER = {s: random.choice(['Premium','Standard','Budget'])
              for s in ALL_STORES}

BRANDS = {
    'Dairy':     ['Amul','Mother Dairy','Nestle','Britannia','Govardhan'],
    'Bakery':    ['Britannia','Harvest Gold','English Oven','Bonn','Local Bakery'],
    'Fruits':    ['Fresh Valley','Nature Best','Organic Farm','Local Farm','Big Basket'],
    'Vegetables':['Fresh Farm','Green Leaf','Village Fresh','Organic Green','Local'],
    'Meat':      ['Venky\'s','Suguna','FreshToHome','Licious','Local Butcher'],
    'Seafood':   ['FishWala','FreshToHome','Licious','Captain Fresh','Local'],
    'Frozen':    ['McCain','Godrej Yummiez','ITC','Haldirams','Cremica'],
    'Beverages': ['Coca Cola','PepsiCo','Dabur','Parle Agro','Paper Boat'],
    'Snacks':    ['Haldirams','Bingo','Lay\'s','Kurkure','Too Yumm'],
    'Condiments':['MDH','Everest','Heinz','Kissan','Maggi'],
    'Grains':    ['India Gate','Daawat','Fortune','Patanjali','Aashirvaad'],
    'Organic':   ['24 Mantra','Organic India','Down to Earth','Praakritik','Nourish'],
}

SUPPLIERS = {}
for cat in CATEGORIES:
    for i in range(1,5):
        sid = f'SUP_{cat[:3].upper()}_{i:02d}'
        SUPPLIERS[sid] = {
            'Category':cat,
            'Supplier_Name': f'{cat} Supplier {i}',
            'Lead_Time_Days': random.randint(1,7),
            'Reliability_Score': round(random.uniform(0.72,0.99),2),
            'Region': random.choice(REGIONS),
        }

CUSTOMER_TYPES = ['Regular','Premium','Occasional','Bulk_Buyer','Senior']
FESTIVALS = {
    (1,26):'Republic Day',(3,8):'Holi',(4,14):'Baisakhi',
    (8,15):'Independence Day',(10,2):'Gandhi Jayanti',
    (10,24):'Dussehra',(11,1):'Diwali',(12,25):'Christmas',
    (1,1):'New Year',
}

# ── TABLE 1: PRODUCTS ──────────────────────────────────────────────────────────
print("Building Products table...")
products_rows = []
pid = 1
for cat, cfg in CATEGORIES.items():
    n_products = random.randint(20, 35)
    for _ in range(n_products):
        cost  = round(random.uniform(*cfg['base_cost']), 2)
        marg  = random.uniform(*cfg['margin'])
        price = round(cost * (1 + marg), 2)
        lo, hi = cfg['shelf_days']
        shelf  = random.randint(lo, hi)
        mfg_dt = START - timedelta(days=random.randint(0, shelf))
        exp_dt = mfg_dt + timedelta(days=shelf)
        brand  = random.choice(BRANDS[cat])
        sup_id = random.choice([k for k in SUPPLIERS if SUPPLIERS[k]['Category']==cat])
        products_rows.append({
            'Product_ID':          f'PRD{pid:05d}',
            'Product_Name':        f'{brand} {cat} {pid}',
            'Category':            cat,
            'Brand':               brand,
            'Supplier_ID':         sup_id,
            'Purchase_Cost':       cost,
            'Selling_Price':       price,
            'Profit_Per_Unit':     round(price - cost, 2),
            'Margin_Pct':          round(marg * 100, 2),
            'Shelf_Life_Days':     shelf,
            'Manufacturing_Date':  mfg_dt.strftime('%Y-%m-%d'),
            'Expiry_Date':         exp_dt.strftime('%Y-%m-%d'),
            'Min_Stock_Level':     random.randint(20, 100),
            'Reorder_Point':       random.randint(50, 200),
            'Unit':                random.choice(['kg','pack','piece','litre','dozen']),
            'Storage_Temp_C':      random.choice([4,4,4,-18,-18,22,22]),
        })
        pid += 1
products = pd.DataFrame(products_rows)
products.to_csv(f'{OUT}/products.csv', index=False)
print(f"  ✔ Products: {len(products)} rows")

# ── TABLE 2: SUPPLIERS ─────────────────────────────────────────────────────────
print("Building Suppliers table...")
sup_rows = []
for sid, info in SUPPLIERS.items():
    sup_rows.append({
        'Supplier_ID':       sid,
        'Supplier_Name':     info['Supplier_Name'],
        'Category':          info['Category'],
        'Region':            info['Region'],
        'Lead_Time_Days':    info['Lead_Time_Days'],
        'Reliability_Score': info['Reliability_Score'],
        'Min_Order_Qty':     random.randint(50, 500),
        'Payment_Terms_Days':random.choice([7,14,21,30,45]),
        'Contract_Start':    (START - timedelta(days=random.randint(100,500))).strftime('%Y-%m-%d'),
        'Rating':            round(random.uniform(3.0, 5.0), 1),
        'On_Time_Delivery_Pct': round(random.uniform(78, 99), 1),
        'Defect_Rate_Pct':  round(random.uniform(0.1, 3.5), 2),
    })
suppliers = pd.DataFrame(sup_rows)
suppliers.to_csv(f'{OUT}/suppliers.csv', index=False)
print(f"  ✔ Suppliers: {len(suppliers)} rows")

# ── TABLE 3: STORES ────────────────────────────────────────────────────────────
print("Building Stores table...")
store_rows = []
for region, store_list in STORES.items():
    for store in store_list:
        tier = STORE_TIER[store]
        store_rows.append({
            'Store_ID':         store,
            'Store_Name':       f'{region} {tier} Market - {store[-3:]}',
            'Region':           region,
            'Tier':             tier,
            'City':             random.choice(['Mumbai','Delhi','Bangalore','Chennai',
                                               'Hyderabad','Pune','Kolkata','Ahmedabad']),
            'Area_SqFt':        random.randint(8000, 45000),
            'Opening_Year':     random.randint(2010, 2020),
            'Manager':          f'Manager_{store[-3:]}',
            'Staff_Count':      random.randint(25, 120),
            'Cold_Storage_Pct': round(random.uniform(0.20, 0.45), 2),
            'Avg_Daily_Footfall':random.randint(400, 3500),
            'Has_Online_Order': random.choice([True,True,False]),
        })
stores = pd.DataFrame(store_rows)
stores.to_csv(f'{OUT}/stores.csv', index=False)
print(f"  ✔ Stores: {len(stores)} rows")

# ── TABLE 4: CUSTOMERS ─────────────────────────────────────────────────────────
print("Building Customers table...")
cust_rows = []
for i in range(1, 5001):
    ctype = random.choice(CUSTOMER_TYPES)
    cust_rows.append({
        'Customer_ID':      f'CUST{i:05d}',
        'Customer_Type':    ctype,
        'Region':           random.choice(REGIONS),
        'Age_Group':        random.choice(['18-25','26-35','36-45','46-55','55+']),
        'Loyalty_Score':    random.randint(1, 100),
        'Avg_Basket_Size':  round(random.uniform(300, 4000), 2),
        'Visit_Frequency':  random.choice(['Daily','Weekly','Bi-weekly','Monthly']),
        'Online_Shopper':   random.choice([True,False,False]),
        'Member_Since':     (START - timedelta(days=random.randint(0,1800))).strftime('%Y-%m-%d'),
    })
customers = pd.DataFrame(cust_rows)
customers.to_csv(f'{OUT}/customers.csv', index=False)
print(f"  ✔ Customers: {len(customers)} rows")

# ── TABLE 5: WEATHER ───────────────────────────────────────────────────────────
print("Building Weather table...")
weather_rows = []
for region in REGIONS:
    for d in range(DAYS):
        dt = START + timedelta(days=d)
        month = dt.month
        # realistic seasonal temp for Indian climate
        base_temp = {1:16,2:19,3:26,4:33,5:37,6:33,7:29,8:28,9:28,10:26,11:21,12:17}[month]
        temp = round(base_temp + np.random.normal(0, 3), 1)
        # monsoon rainfall pattern
        rain_prob = {6:0.6,7:0.75,8:0.7,9:0.55}.get(month, 0.1)
        rainfall  = round(max(0, np.random.exponential(15)) if random.random()<rain_prob else 0, 1)
        humidity  = round(min(95, max(30, 45 + rainfall*1.2 + np.random.normal(0,8))), 1)
        weather_rows.append({
            'Date':       dt.strftime('%Y-%m-%d'),
            'Region':     region,
            'Temperature_C': temp,
            'Rainfall_mm':   rainfall,
            'Humidity_Pct':  humidity,
            'Weather_Condition': ('Rainy' if rainfall>5 else ('Hot' if temp>35 else ('Cold' if temp<15 else 'Normal'))),
        })
weather = pd.DataFrame(weather_rows)
weather.to_csv(f'{OUT}/weather.csv', index=False)
print(f"  ✔ Weather: {len(weather)} rows")

# ── TABLE 6: HOLIDAYS / PROMOTIONS CALENDAR ────────────────────────────────────
print("Building Holidays table...")
hol_rows = []
for d in range(DAYS):
    dt = START + timedelta(days=d)
    key = (dt.month, dt.day)
    is_weekend = dt.weekday() >= 5
    festival   = FESTIVALS.get(key, '')
    is_holiday = bool(festival) or is_weekend
    demand_mult = 1.0
    if festival: demand_mult = round(random.uniform(1.3, 2.1), 2)
    elif is_weekend: demand_mult = round(random.uniform(1.1, 1.4), 2)
    hol_rows.append({
        'Date':           dt.strftime('%Y-%m-%d'),
        'Day_Of_Week':    dt.strftime('%A'),
        'Is_Weekend':     is_weekend,
        'Is_Holiday':     is_holiday,
        'Festival_Name':  festival,
        'Demand_Multiplier': demand_mult,
        'Season':         {12:'Winter',1:'Winter',2:'Winter',
                           3:'Summer',4:'Summer',5:'Summer',
                           6:'Monsoon',7:'Monsoon',8:'Monsoon',9:'Monsoon',
                           10:'Post-Monsoon',11:'Post-Monsoon'}[dt.month],
    })
holidays = pd.DataFrame(hol_rows)
holidays.to_csv(f'{OUT}/holidays.csv', index=False)
print(f"  ✔ Holidays: {len(holidays)} rows")

# ── TABLE 7: PROMOTIONS ────────────────────────────────────────────────────────
print("Building Promotions table...")
promo_rows = []
promo_id = 1
date_range = pd.date_range(START, END)
# generate ~300 promotions over 3 years
for _ in range(300):
    start_d = random.choice(date_range)
    dur     = random.randint(2, 14)
    end_d   = min(start_d + timedelta(days=dur), pd.Timestamp(END))
    cat     = random.choice(list(CATEGORIES.keys()))
    promo_type = random.choice(['BOGO','Flat_Discount','Bundle','Clearance','Flash_Sale','Loyalty'])
    disc_pct   = {'BOGO':50,'Flat_Discount':random.randint(10,30),
                  'Bundle':15,'Clearance':random.randint(25,60),
                  'Flash_Sale':random.randint(20,40),'Loyalty':10}[promo_type]
    promo_rows.append({
        'Promo_ID':      f'PROMO{promo_id:04d}',
        'Promo_Name':    f'{promo_type}_{cat}_{promo_id}',
        'Category':      cat,
        'Store_ID':      random.choice(ALL_STORES + ['ALL']),
        'Promo_Type':    promo_type,
        'Discount_Pct':  disc_pct,
        'Start_Date':    start_d.strftime('%Y-%m-%d'),
        'End_Date':      end_d.strftime('%Y-%m-%d'),
        'Min_Purchase':  random.choice([0,200,500,1000]),
        'Budget_INR':    random.randint(10000, 200000),
        'Target_Revenue':random.randint(50000, 500000),
    })
    promo_id += 1
promotions = pd.DataFrame(promo_rows)
promotions.to_csv(f'{OUT}/promotions.csv', index=False)
print(f"  ✔ Promotions: {len(promotions)} rows")

# ── TABLES 8-10: INVENTORY, SALES, WASTE (core — ~120k total) ─────────────────
print("\nBuilding core transactional tables (this takes ~60s)...")
inv_rows, sales_rows, waste_rows = [], [], []
inv_id = sales_id = waste_id = 1

# sample product subset per store for realism (not every store stocks every product)
store_products = {}
for store in ALL_STORES:
    n_products = random.randint(180, len(products))
    store_products[store] = products.sample(n_products)['Product_ID'].tolist()

hol_lookup  = holidays.set_index('Date')['Demand_Multiplier'].to_dict()
hol_season  = holidays.set_index('Date')['Season'].to_dict()
wx_lookup   = weather.set_index(['Date','Region'])[['Temperature_C','Rainfall_mm']].to_dict('index')

date_range_list = [(START + timedelta(days=d)).strftime('%Y-%m-%d') for d in range(DAYS)]

for store in ALL_STORES:
    region   = next(r for r,sl in STORES.items() if store in sl)
    tier     = STORE_TIER[store]
    tier_mult= {'Premium':1.35,'Standard':1.0,'Budget':0.72}[tier]
    prods    = store_products[store]

    # Sample ~15 dates per product (not daily — gives realistic sparse inventory logs)
    for prod_id in prods:
        prod_row = products[products['Product_ID']==prod_id].iloc[0]
        cat      = prod_row['Category']
        cfg      = CATEGORIES[cat]
        cost     = prod_row['Purchase_Cost']
        price    = prod_row['Selling_Price']
        shelf    = prod_row['Shelf_Life_Days']
        min_stk  = prod_row['Min_Stock_Level']

        # pick ~12 observation dates per product-store
        obs_dates = sorted(random.sample(date_range_list, min(12, len(date_range_list))))

        for dt_str in obs_dates:
            dt       = datetime.strptime(dt_str,'%Y-%m-%d')
            dem_mult = hol_lookup.get(dt_str, 1.0)
            wx_key   = (dt_str, region)
            temp     = wx_lookup.get(wx_key,{}).get('Temperature_C', 28)
            rain     = wx_lookup.get(wx_key,{}).get('Rainfall_mm', 0)
            season   = hol_season.get(dt_str,'Normal')

            # DEMAND MODEL: category base × season × weather × tier × random noise
            season_factor = {'Summer':1.1,'Monsoon':0.9,'Winter':1.05,'Post-Monsoon':1.0}.get(season,1.0)
            if cat in ('Beverages','Frozen') and temp > 32: season_factor *= 1.15
            if cat == 'Vegetables' and rain > 10: season_factor *= 0.85  # rain = fewer shoppers
            base_demand = int(random.randint(20,200) * tier_mult * dem_mult * season_factor)

            # STOCK LEVEL
            stock_rcvd  = random.randint(base_demand, base_demand + 150)
            stock_level = max(0, stock_rcvd - random.randint(0, base_demand))
            is_stockout = stock_level < min_stk

            # ACTIVE PROMO?
            active_promos = promotions[
                (promotions['Start_Date'] <= dt_str) &
                (promotions['End_Date']   >= dt_str) &
                ((promotions['Category']==cat) | (promotions['Store_ID']=='ALL')) &
                ((promotions['Store_ID']==store) | (promotions['Store_ID']=='ALL'))
            ]
            discount_pct = float(active_promos['Discount_Pct'].max()) if len(active_promos)>0 else 0.0
            promo_active = len(active_promos) > 0

            # SALES
            promo_boost  = 1 + discount_pct/200  # discounts lift volume ~0.5× discount
            qty_sold = min(stock_rcvd,
                           int(base_demand * promo_boost * random.uniform(0.7,1.2)))
            effective_price = round(price * (1 - discount_pct/100), 2)
            revenue    = round(qty_sold * effective_price, 2)
            cogs       = round(qty_sold * cost, 2)
            profit_val = round(revenue - cogs, 2)
            margin_pct = round((profit_val / revenue * 100) if revenue > 0 else 0, 2)

            # WASTE
            waste_base_rate = random.uniform(*cfg['waste_rate'])
            if temp > 35:   waste_base_rate *= 1.3
            if shelf < 5:   waste_base_rate *= 1.5
            if discount_pct > 20: waste_base_rate *= 0.7  # promo clears stock
            waste_qty = int(max(0, (stock_rcvd - qty_sold) * waste_base_rate))
            waste_val = round(waste_qty * cost, 2)
            waste_reason = random.choices(
                ['Expiry','Damage','Quality_Reject','Over_Stock','Cold_Chain_Break'],
                weights=[40,20,15,15,10])[0]

            # near-expiry flag (within 2 days of shelf life)
            days_to_expiry = shelf - random.randint(0, shelf)
            near_expiry    = days_to_expiry <= 2

            # INVENTORY ROW
            inv_rows.append({
                'Inv_ID':           f'INV{inv_id:07d}',
                'Date':             dt_str,
                'Store_ID':         store,
                'Region':           region,
                'Product_ID':       prod_id,
                'Category':         cat,
                'Stock_Received':   stock_rcvd,
                'Stock_Level':      stock_level,
                'Min_Stock_Level':  min_stk,
                'Is_Stockout':      is_stockout,
                'Days_To_Expiry':   max(0, days_to_expiry),
                'Near_Expiry_Flag': near_expiry,
                'Reorder_Triggered':is_stockout,
                'Temperature_C':    round(temp,1),
                'Rainfall_mm':      round(rain,1),
                'Season':           season,
                'Demand_Forecast':  base_demand,
                'Actual_Demand':    qty_sold,
                'Forecast_Error':   abs(base_demand - qty_sold),
                'Forecast_Acc_Pct': round(max(0,100 - abs(base_demand-qty_sold)/max(1,base_demand)*100),1),
            })
            inv_id += 1

            # SALES ROW
            cust = customers.sample(1).iloc[0]
            sales_rows.append({
                'Sale_ID':          f'SAL{sales_id:07d}',
                'Date':             dt_str,
                'Store_ID':         store,
                'Region':           region,
                'Product_ID':       prod_id,
                'Category':         cat,
                'Customer_ID':      cust['Customer_ID'],
                'Customer_Type':    cust['Customer_Type'],
                'Quantity_Sold':    qty_sold,
                'Purchase_Cost':    cost,
                'Selling_Price':    price,
                'Effective_Price':  effective_price,
                'Discount_Pct':     discount_pct,
                'Promo_Active':     promo_active,
                'Revenue':          revenue,
                'COGS':             cogs,
                'Gross_Profit':     profit_val,
                'Gross_Margin_Pct': margin_pct,
                'Is_Weekend':       dt.weekday()>=5,
                'Festival':         hol_lookup.get(dt_str,'') if hol_lookup.get(dt_str,1.0)>1.1 else '',
            })
            sales_id += 1

            # WASTE ROW
            if waste_qty > 0:
                waste_rows.append({
                    'Waste_ID':        f'WST{waste_id:07d}',
                    'Date':            dt_str,
                    'Store_ID':        store,
                    'Region':          region,
                    'Product_ID':      prod_id,
                    'Category':        cat,
                    'Waste_Quantity':  waste_qty,
                    'Waste_Value_INR': waste_val,
                    'Waste_Reason':    waste_reason,
                    'Temperature_C':   round(temp,1),
                    'Days_To_Expiry':  max(0,days_to_expiry),
                    'Near_Expiry':     near_expiry,
                    'Season':          season,
                    'Preventable':     waste_reason in ('Over_Stock','Expiry'),
                })
                waste_id += 1

inventory = pd.DataFrame(inv_rows)
sales     = pd.DataFrame(sales_rows)
waste     = pd.DataFrame(waste_rows)

inventory.to_csv(f'{OUT}/inventory.csv', index=False)
sales.to_csv(f'{OUT}/sales.csv', index=False)
waste.to_csv(f'{OUT}/waste.csv', index=False)

total = len(inventory)+len(sales)+len(waste)+len(products)+len(suppliers)+len(stores)+len(customers)+len(weather)+len(holidays)+len(promotions)

print(f"\n  ✔ Inventory : {len(inventory):>8,} rows")
print(f"  ✔ Sales     : {len(sales):>8,} rows")
print(f"  ✔ Waste     : {len(waste):>8,} rows")
print(f"\n{'─'*40}")
print(f"  TOTAL RECORDS : {total:>8,}")
print(f"{'─'*40}")
print(f"\n✅ All 10 tables saved to {OUT}/")
