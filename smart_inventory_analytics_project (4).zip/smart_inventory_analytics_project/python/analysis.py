"""
Smart Inventory & Food Waste Analytics Platform
Python Analysis: Cleaning → EDA → KPIs → Forecasting → Charts
"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import warnings, os
warnings.filterwarnings('ignore')

try:
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    HAS_SM = True
except: HAS_SM = False

DATA = '/home/claude/inventory_analytics/data'
OUT  = '/home/claude/inventory_analytics/python'
os.makedirs(OUT, exist_ok=True)

# ── LOAD ───────────────────────────────────────────────────────────────────────
print("="*60); print("  LOADING & CLEANING"); print("="*60)
inv   = pd.read_csv(f'{DATA}/inventory.csv',  parse_dates=['Date'])
sales = pd.read_csv(f'{DATA}/sales.csv',       parse_dates=['Date'])
waste = pd.read_csv(f'{DATA}/waste.csv',       parse_dates=['Date'])
prods = pd.read_csv(f'{DATA}/products.csv')
sups  = pd.read_csv(f'{DATA}/suppliers.csv')
stores= pd.read_csv(f'{DATA}/stores.csv')

# ── CLEANING ───────────────────────────────────────────────────────────────────
for df, name in [(inv,'Inventory'),(sales,'Sales'),(waste,'Waste')]:
    dupes = df.duplicated().sum()
    nulls = df.isnull().sum().sum()
    print(f"  {name}: {len(df):,} rows | Dupes: {dupes} | Nulls: {nulls}")

sales['Revenue']          = sales['Revenue'].clip(lower=0)
sales['Gross_Profit']     = sales['Gross_Profit']
sales['Gross_Margin_Pct'] = sales['Gross_Margin_Pct'].clip(-100, 100)
inv['Forecast_Acc_Pct']   = inv['Forecast_Acc_Pct'].clip(0, 100)
waste['Waste_Value_INR']  = waste['Waste_Value_INR'].clip(lower=0)

# derived
sales['Year']    = sales['Date'].dt.year
sales['Month']   = sales['Date'].dt.month
sales['Quarter'] = sales['Date'].dt.quarter
sales['YM']      = sales['Date'].dt.to_period('M')

inv['Year']  = inv['Date'].dt.year
inv['Month'] = inv['Date'].dt.month

waste['Year']  = waste['Date'].dt.year
waste['Month'] = waste['Date'].dt.month
waste['YM']    = waste['Date'].dt.to_period('M')

print("\n✅ Data Cleaning Complete")

# ── KPI CALCULATION ────────────────────────────────────────────────────────────
print("\n"+"="*60); print("  KEY PERFORMANCE INDICATORS"); print("="*60)

total_rev     = sales['Revenue'].sum()
total_profit  = sales['Gross_Profit'].sum()
overall_margin= total_profit/total_rev*100
total_waste_v = waste['Waste_Value_INR'].sum()
waste_pct     = total_waste_v / (total_rev + total_waste_v) * 100
stockout_rate = inv['Is_Stockout'].mean() * 100
avg_fc_acc    = inv['Forecast_Acc_Pct'].mean()
near_exp_count= inv['Near_Expiry_Flag'].sum()
preventable_w = waste[waste['Preventable']==True]['Waste_Value_INR'].sum()
total_cogs = sales['COGS'].sum()
inv_with_value = inv.merge(prods[['Product_ID','Purchase_Cost']], on='Product_ID')
inv_with_value['Inv_Value'] = inv_with_value['Stock_Level'] * inv_with_value['Purchase_Cost']
# Scale to estimate true daily on-hand inventory value across the full catalog
# (observations are sampled ~12x per product-store rather than daily, so we annualize via days span)
days_span = (inv['Date'].max() - inv['Date'].min()).days
avg_inv_value_per_snapshot = inv_with_value.groupby('Date')['Inv_Value'].sum().mean()
inv_turnover = round(total_cogs / max(1, avg_inv_value_per_snapshot * (days_span/12)), 2)

kpis = {
    'Total Revenue (₹)':         total_rev,
    'Total Gross Profit (₹)':    total_profit,
    'Gross Margin %':             overall_margin,
    'Total Waste Value (₹)':      total_waste_v,
    'Waste % of Revenue':         waste_pct,
    'Stockout Rate %':            stockout_rate,
    'Avg Forecast Accuracy %':    avg_fc_acc,
    'Near-Expiry Items (count)':  near_exp_count,
    'Preventable Waste (₹)':      preventable_w,
    'Inventory Turnover Ratio':   inv_turnover,
}
for k,v in kpis.items(): print(f"  {k:<35} {v:>14,.2f}")

# ── PALETTE & HELPERS ──────────────────────────────────────────────────────────
CAT_COLORS = {
    'Dairy':'#42A5F5','Bakery':'#FF7043','Fruits':'#66BB6A',
    'Vegetables':'#26A69A','Meat':'#EF5350','Seafood':'#5C6BC0',
    'Frozen':'#26C6DA','Beverages':'#FFA726','Snacks':'#AB47BC',
    'Condiments':'#8D6E63','Grains':'#78909C','Organic':'#9CCC65',
}
REGION_C = {'North':'#42A5F5','South':'#EF5350','East':'#66BB6A','West':'#FFA726','Central':'#AB47BC'}
RED='#EF5350'; GREEN='#66BB6A'; BLUE='#1565C0'; AMBER='#FFA726'
money = lambda x,p: f'₹{x/1e6:.1f}M' if abs(x)>=1e6 else f'₹{x:,.0f}'
pct   = lambda x,p: f'{x:.1f}%'

def save(name):
    plt.savefig(f'{OUT}/{name}', dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✔ {name}")

# ═══ CHART 1: KPI SUMMARY DASHBOARD ══════════════════════════════════════════
fig = plt.figure(figsize=(16,9)); fig.patch.set_facecolor('#0d1117')
gs  = gridspec.GridSpec(3,4, figure=fig, hspace=0.5, wspace=0.4)

cards = [
    ('Total Revenue', f'₹{total_rev/1e6:.1f}M', GREEN),
    ('Gross Profit',  f'₹{total_profit/1e6:.1f}M', GREEN if total_profit>0 else RED),
    ('Gross Margin',  f'{overall_margin:.1f}%', GREEN),
    ('Waste Value',   f'₹{total_waste_v/1e6:.1f}M', RED),
    ('Waste %',       f'{waste_pct:.1f}%', RED),
    ('Stockout Rate', f'{stockout_rate:.1f}%', AMBER),
    ('Forecast Acc.', f'{avg_fc_acc:.1f}%', GREEN),
    ('Inv. Turnover', f'{inv_turnover:.1f}x', BLUE),
]
for i,(title,val,color) in enumerate(cards):
    ax = fig.add_subplot(gs[i//4, i%4])
    ax.set_facecolor('#161b22'); ax.set_xticks([]); ax.set_yticks([])
    for spine in ax.spines.values(): spine.set_edgecolor('#30363d')
    ax.text(0.5,0.62,val,ha='center',va='center',transform=ax.transAxes,
            fontsize=20,fontweight='bold',color=color)
    ax.text(0.5,0.22,title,ha='center',va='center',transform=ax.transAxes,
            fontsize=9,color='#8b949e')

fig.suptitle('🛒 Smart Inventory & Food Waste Analytics — KPI Dashboard',
             fontsize=14, fontweight='bold', color='white', y=0.98)
save('01_kpi_dashboard.png')

# ═══ CHART 2: REVENUE & PROFIT TREND ═════════════════════════════════════════
monthly = sales.groupby('YM').agg(Revenue=('Revenue','sum'),Profit=('Gross_Profit','sum')).reset_index()
monthly['YM_str'] = monthly['YM'].astype(str)

fig,(ax1,ax2) = plt.subplots(2,1,figsize=(14,8),sharex=True)
fig.suptitle('Monthly Revenue & Profit Trend', fontsize=14, fontweight='bold')
ax1.fill_between(range(len(monthly)),monthly['Revenue']/1e6,alpha=0.3,color=BLUE)
ax1.plot(range(len(monthly)),monthly['Revenue']/1e6,color=BLUE,linewidth=2)
ax1.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.1f}M'))
ax1.set_title('Monthly Revenue (₹ Millions)'); ax1.set_ylabel('Revenue')

bars=[GREEN if p>=0 else RED for p in monthly['Profit']]
ax2.bar(range(len(monthly)),monthly['Profit']/1e6,color=bars,width=0.8)
ax2.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.1f}M'))
ax2.set_title('Monthly Gross Profit'); ax2.set_ylabel('Profit')
step=12
ax2.set_xticks(range(0,len(monthly),step))
ax2.set_xticklabels([monthly['YM_str'].iloc[i] for i in range(0,len(monthly),step)],rotation=30)
plt.tight_layout(); save('02_revenue_profit_trend.png')

# ═══ CHART 3: WASTE HEATMAP ══════════════════════════════════════════════════
waste_heat = waste.groupby(['Category','Season'])['Waste_Value_INR'].sum().unstack(fill_value=0)
fig,ax = plt.subplots(figsize=(12,7))
import matplotlib.colors as mcolors
cmap = plt.cm.YlOrRd
im   = ax.imshow(waste_heat.values/1e3, cmap=cmap, aspect='auto')
ax.set_xticks(range(len(waste_heat.columns))); ax.set_xticklabels(waste_heat.columns,rotation=15)
ax.set_yticks(range(len(waste_heat.index)));  ax.set_yticklabels(waste_heat.index)
plt.colorbar(im,ax=ax,label='Waste Value (₹ Thousands)')
for i in range(len(waste_heat.index)):
    for j in range(len(waste_heat.columns)):
        val = waste_heat.values[i,j]/1e3
        ax.text(j,i,f'₹{val:.0f}K',ha='center',va='center',fontsize=8,
                color='white' if val>waste_heat.values.max()/2e3 else 'black')
ax.set_title('🗑️ Waste Value Heatmap — Category × Season (₹K)', fontsize=13,fontweight='bold')
plt.tight_layout(); save('03_waste_heatmap.png')

# ═══ CHART 4: TOP WASTE CATEGORIES ══════════════════════════════════════════
waste_cat = waste.groupby('Category').agg(
    Waste_Val=('Waste_Value_INR','sum'),
    Waste_Qty=('Waste_Quantity','sum'),
    Preventable=('Waste_Value_INR', lambda x: waste.loc[x.index[waste.loc[x.index,'Preventable']==True],'Waste_Value_INR'].sum())
).sort_values('Waste_Val',ascending=False).reset_index()
waste_cat['Preventable_Pct'] = waste_cat['Preventable']/waste_cat['Waste_Val']*100

fig,axes = plt.subplots(1,2,figsize=(14,6))
fig.suptitle('Waste Analysis by Category', fontsize=14,fontweight='bold')
colors=[CAT_COLORS.get(c,'#90A4AE') for c in waste_cat['Category']]
axes[0].barh(waste_cat['Category'],waste_cat['Waste_Val']/1e6,color=colors)
axes[0].xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.1f}M'))
axes[0].set_title('Total Waste Value (₹M)'); axes[0].invert_yaxis()

axes[1].barh(waste_cat['Category'],waste_cat['Preventable_Pct'],color=RED,alpha=0.8)
axes[1].axvline(waste_cat['Preventable_Pct'].mean(),color='black',linestyle='--',linewidth=1.2,label='Avg')
axes[1].xaxis.set_major_formatter(FuncFormatter(pct))
axes[1].set_title('Preventable Waste %'); axes[1].invert_yaxis(); axes[1].legend()
plt.tight_layout(); save('04_waste_by_category.png')

# ═══ CHART 5: INVENTORY HEALTH ════════════════════════════════════════════════
stockout_cat = inv.groupby('Category')['Is_Stockout'].mean()*100
near_exp_cat  = inv.groupby('Category')['Near_Expiry_Flag'].mean()*100
fc_acc_cat    = inv.groupby('Category')['Forecast_Acc_Pct'].mean()

fig,axes = plt.subplots(1,3,figsize=(15,6))
fig.suptitle('Inventory Health Metrics by Category',fontsize=14,fontweight='bold')

cats = stockout_cat.index
colors_s=[RED if v>15 else (AMBER if v>8 else GREEN) for v in stockout_cat.values]
axes[0].bar(cats,stockout_cat.values,color=colors_s)
axes[0].yaxis.set_major_formatter(FuncFormatter(pct))
axes[0].set_title('Stockout Rate %'); axes[0].set_xticklabels(cats,rotation=45,ha='right')
axes[0].axhline(stockout_cat.mean(),color='black',linestyle='--',linewidth=1)

colors_n=[RED if v>10 else (AMBER if v>5 else GREEN) for v in near_exp_cat.values]
axes[1].bar(near_exp_cat.index,near_exp_cat.values,color=colors_n)
axes[1].yaxis.set_major_formatter(FuncFormatter(pct))
axes[1].set_title('Near-Expiry Rate %'); axes[1].set_xticklabels(near_exp_cat.index,rotation=45,ha='right')

colors_f=[GREEN if v>85 else (AMBER if v>70 else RED) for v in fc_acc_cat.values]
axes[2].bar(fc_acc_cat.index,fc_acc_cat.values,color=colors_f)
axes[2].yaxis.set_major_formatter(FuncFormatter(pct))
axes[2].set_title('Forecast Accuracy %'); axes[2].set_xticklabels(fc_acc_cat.index,rotation=45,ha='right')
axes[2].set_ylim(0,100)

plt.tight_layout(); save('05_inventory_health.png')

# ═══ CHART 6: REGIONAL PERFORMANCE ══════════════════════════════════════════
reg_sales = sales.groupby('Region').agg(Rev=('Revenue','sum'),Prof=('Gross_Profit','sum')).reset_index()
reg_waste = waste.groupby('Region')['Waste_Value_INR'].sum().reset_index()
reg = reg_sales.merge(reg_waste,on='Region')
reg['Margin']=reg['Prof']/reg['Rev']*100
reg['Waste_Rev_Pct']=reg['Waste_Value_INR']/reg['Rev']*100

fig,axes=plt.subplots(1,3,figsize=(15,5))
fig.suptitle('Regional Performance',fontsize=14,fontweight='bold')
rcolors=[REGION_C[r] for r in reg['Region']]

axes[0].bar(reg['Region'],reg['Rev']/1e6,color=rcolors)
axes[0].yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.0f}M'))
axes[0].set_title('Revenue by Region')

axes[1].bar(reg['Region'],reg['Margin'],color=rcolors)
axes[1].yaxis.set_major_formatter(FuncFormatter(pct))
axes[1].set_title('Gross Margin %')

axes[2].bar(reg['Region'],reg['Waste_Rev_Pct'],color=RED,alpha=0.75)
axes[2].yaxis.set_major_formatter(FuncFormatter(pct))
axes[2].set_title('Waste as % of Revenue')

plt.tight_layout(); save('06_regional_performance.png')

# ═══ CHART 7: STORE COMPARISON (TOP 10) ═══════════════════════════════════════
store_perf = sales.groupby('Store_ID').agg(Rev=('Revenue','sum'),Prof=('Gross_Profit','sum')).reset_index()
store_waste= waste.groupby('Store_ID')['Waste_Value_INR'].sum().reset_index()
store_inv  = inv.groupby('Store_ID')['Is_Stockout'].mean().reset_index()
st = store_perf.merge(store_waste,on='Store_ID').merge(store_inv,on='Store_ID')
st['Margin']=st['Prof']/st['Rev']*100
st = st.merge(stores[['Store_ID','Tier']],on='Store_ID')
st = st.sort_values('Rev',ascending=False)

fig,axes=plt.subplots(1,2,figsize=(14,6))
fig.suptitle('Store-Level Performance Comparison',fontsize=14,fontweight='bold')
tier_c={'Premium':BLUE,'Standard':GREEN,'Budget':AMBER}
sc=[tier_c.get(t,'gray') for t in st['Tier']]
axes[0].barh(st['Store_ID'],st['Rev']/1e6,color=sc)
axes[0].xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.0f}M'))
axes[0].set_title('Revenue by Store'); axes[0].invert_yaxis()
patches=[mpatches.Patch(color=v,label=k) for k,v in tier_c.items()]
axes[0].legend(handles=patches,loc='lower right')

axes[1].scatter(st['Rev']/1e6,st['Margin'],
                c=[tier_c.get(t,'gray') for t in st['Tier']],s=120,alpha=0.8)
for _,row in st.iterrows():
    axes[1].annotate(row['Store_ID'],xy=(row['Rev']/1e6,row['Margin']),
                     fontsize=7,ha='left',xytext=(3,3),textcoords='offset points')
axes[1].set_xlabel('Revenue (₹M)'); axes[1].set_ylabel('Gross Margin %')
axes[1].set_title('Revenue vs Margin Scatter')
plt.tight_layout(); save('07_store_comparison.png')

# ═══ CHART 8: SUPPLIER PERFORMANCE ══════════════════════════════════════════
sup_waste=waste.merge(prods[['Product_ID','Supplier_ID']],on='Product_ID').groupby('Supplier_ID')['Waste_Value_INR'].sum().reset_index()
sup_perf=sups.merge(sup_waste,on='Supplier_ID',how='left').fillna(0)
sup_perf=sup_perf.sort_values('On_Time_Delivery_Pct',ascending=False).head(15)

fig,axes=plt.subplots(1,2,figsize=(14,6))
fig.suptitle('Supplier Performance Analysis',fontsize=14,fontweight='bold')
rel_c=[GREEN if r>=0.90 else (AMBER if r>=0.80 else RED) for r in sup_perf['Reliability_Score']]
axes[0].barh(sup_perf['Supplier_ID'],sup_perf['On_Time_Delivery_Pct'],color=rel_c)
axes[0].axvline(90,color=RED,linestyle='--',linewidth=1.2,label='90% target')
axes[0].xaxis.set_major_formatter(FuncFormatter(pct))
axes[0].set_title('On-Time Delivery %'); axes[0].invert_yaxis(); axes[0].legend()

axes[1].scatter(sup_perf['Reliability_Score'],sup_perf['Defect_Rate_Pct'],
                c=rel_c,s=100,alpha=0.85)
axes[1].set_xlabel('Reliability Score'); axes[1].set_ylabel('Defect Rate %')
axes[1].set_title('Reliability vs Defect Rate')
axes[1].axhline(sup_perf['Defect_Rate_Pct'].mean(),color='black',linestyle='--',alpha=0.5)
plt.tight_layout(); save('08_supplier_performance.png')

# ═══ CHART 9: WEATHER IMPACT ON WASTE ════════════════════════════════════════
weather_df=pd.read_csv(f'{DATA}/weather.csv', parse_dates=['Date'])
ww=waste.drop(columns=['Temperature_C']).merge(
               weather_df[['Date','Region','Temperature_C','Rainfall_mm','Weather_Condition']],
               on=['Date','Region'],how='left').dropna(subset=['Temperature_C'])
ww['Temp_Band']=pd.cut(ww['Temperature_C'],bins=[0,20,28,34,50],
                         labels=['Cold<20°','Normal 20-28°','Warm 28-34°','Hot>34°'])
waste_by_temp=ww.groupby('Temp_Band')['Waste_Value_INR'].mean().reset_index()

fig,axes=plt.subplots(1,2,figsize=(14,5))
fig.suptitle('Weather Impact on Waste',fontsize=14,fontweight='bold')
temp_colors=['#42A5F5','#66BB6A','#FFA726','#EF5350']
axes[0].bar(waste_by_temp['Temp_Band'].astype(str),waste_by_temp['Waste_Value_INR']/1e3,
            color=temp_colors[:len(waste_by_temp)])
axes[0].yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.0f}K'))
axes[0].set_title('Avg Waste Value by Temperature Band'); axes[0].set_xticklabels(waste_by_temp['Temp_Band'].astype(str),rotation=15)

axes[1].scatter(ww['Temperature_C'],ww['Waste_Value_INR']/1e3,
                alpha=0.1,s=5,color=RED)
z=np.polyfit(ww['Temperature_C'].dropna(),
              ww.loc[ww['Temperature_C'].notna(),'Waste_Value_INR']/1e3,1)
xr=np.linspace(ww['Temperature_C'].min(),ww['Temperature_C'].max(),100)
axes[1].plot(xr,np.poly1d(z)(xr),color='black',linewidth=2,label='Trend')
axes[1].set_xlabel('Temperature (°C)'); axes[1].set_ylabel('Waste Value (₹K)')
axes[1].set_title('Temperature vs Waste Value'); axes[1].legend()
plt.tight_layout(); save('09_weather_waste_impact.png')

# ═══ CHART 10: DEMAND FORECAST ════════════════════════════════════════════════
monthly_sales_ts=sales.groupby('YM')['Revenue'].sum().reset_index().sort_values('YM')
ts_vals=monthly_sales_ts['Revenue'].values
ym_strs=monthly_sales_ts['YM'].astype(str).tolist()

if HAS_SM and len(ts_vals)>=24:
    model=ExponentialSmoothing(ts_vals,trend='add',seasonal='add',seasonal_periods=12)
    fit=model.fit(optimized=True,use_brute=False)
    fc=fit.forecast(12); ci=fit.resid.std()*1.96
    fc_lo,fc_hi=fc-ci,fc+ci
    method='Holt-Winters'
else:
    x=np.arange(len(ts_vals)); m,b=np.polyfit(x,ts_vals,1)
    fc=np.array([m*(len(ts_vals)+i)+b for i in range(12)])
    fc_lo,fc_hi=fc*0.88,fc*1.12; method='Linear Trend'

from pandas import Period
lp=Period(ym_strs[-1],'M')
fut=[(lp+i+1).strftime('%Y-%m') for i in range(12)]

fig,ax=plt.subplots(figsize=(14,6))
xh=range(len(ts_vals)); xf=range(len(ts_vals),len(ts_vals)+12)
ax.fill_between(xh,ts_vals/1e6,alpha=0.2,color=BLUE)
ax.plot(xh,np.array(ts_vals)/1e6,color=BLUE,linewidth=2,label='Actual Revenue')
ax.plot(xf,fc/1e6,color=RED,linewidth=2.5,linestyle='--',label='12-Month Forecast')
ax.fill_between(xf,fc_lo/1e6,fc_hi/1e6,color=RED,alpha=0.15,label='95% CI')
ax.axvline(len(ts_vals)-0.5,color='gray',linestyle=':')
ax.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.1f}M'))
ax.set_title(f'12-Month Revenue Forecast — {method}',fontsize=13,fontweight='bold')
ax.set_xlabel('Month'); ax.set_ylabel('Monthly Revenue (₹M)'); ax.legend()
step=6
all_labels=ym_strs+fut
ticks=list(range(0,len(ts_vals),step))+list(xf)[::step]
ax.set_xticks(ticks)
ax.set_xticklabels([all_labels[i] for i in ticks],rotation=30,ha='right')
plt.tight_layout(); save('10_demand_forecast.png')

# ═══ CHART 11: WASTE REASON ANALYSIS ═════════════════════════════════════════
waste_reason=waste.groupby('Waste_Reason').agg(
    Val=('Waste_Value_INR','sum'),Qty=('Waste_Quantity','sum')).sort_values('Val',ascending=False)

fig,(ax1,ax2)=plt.subplots(1,2,figsize=(13,6))
fig.suptitle('Waste Root-Cause Analysis',fontsize=14,fontweight='bold')
reas_colors=[RED,'#FF7043','#FFA726','#FFCC02','#66BB6A']
ax1.pie(waste_reason['Val'],labels=waste_reason.index,autopct='%1.1f%%',
        colors=reas_colors[:len(waste_reason)],startangle=90,pctdistance=0.8)
ax1.set_title('Waste Value by Reason')
ax2.barh(waste_reason.index,waste_reason['Val']/1e6,color=reas_colors[:len(waste_reason)])
ax2.xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'₹{x:.1f}M'))
ax2.set_title('Waste Value (₹M) by Root Cause'); ax2.invert_yaxis()
plt.tight_layout(); save('11_waste_root_cause.png')

# ═══ CHART 12: PROMO IMPACT ════════════════════════════════════════════════════
promo_comp=sales.groupby('Promo_Active').agg(
    Revenue=('Revenue','mean'),Margin=('Gross_Margin_Pct','mean'),
    Qty=('Quantity_Sold','mean')).reset_index()
promo_comp['Label']=['No Promo','Promo Active']

fig,axes=plt.subplots(1,3,figsize=(13,5))
fig.suptitle('Promotion Impact on Sales Metrics',fontsize=14,fontweight='bold')
for i,(col,title) in enumerate([('Revenue','Avg Revenue/Transaction'),
                                  ('Margin','Avg Gross Margin %'),
                                  ('Qty','Avg Qty Sold')]):
    colors_p=[BLUE,GREEN]
    axes[i].bar(promo_comp['Label'],promo_comp[col],color=colors_p)
    axes[i].set_title(title)
    if col=='Revenue': axes[i].yaxis.set_major_formatter(FuncFormatter(money))
    if col=='Margin':  axes[i].yaxis.set_major_formatter(FuncFormatter(pct))
plt.tight_layout(); save('12_promotion_impact.png')

print(f"\n✅ All 12 charts saved to {OUT}/")
print(f"\n{'─'*50}")
print("  SUMMARY INSIGHTS:")
print(f"  Total Revenue        : ₹{total_rev/1e6:,.1f}M")
print(f"  Total Waste Value    : ₹{total_waste_v/1e6:,.1f}M ({waste_pct:.1f}% of revenue)")
print(f"  Preventable Waste    : ₹{preventable_w/1e6:,.1f}M ({preventable_w/total_waste_v*100:.0f}% of waste)")
print(f"  Stockout Rate        : {stockout_rate:.1f}%")
print(f"  Forecast Accuracy    : {avg_fc_acc:.1f}%")
print(f"  Inventory Turnover   : {inv_turnover:.1f}x")
print(f"{'─'*50}")
